from .main import register_admin_handlers
