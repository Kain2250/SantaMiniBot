from bot.database.methods.create import create_table_users
from bot.misc.env import env_load


def register_models() -> None:
    create_table_users()
    env_load()
