from .main import start_bot
